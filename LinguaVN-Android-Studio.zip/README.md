# LinguaVN - Native Android Visual Novel Overlay Translator

تطبيق أندرويد حقيقي مكتوب بـ **Kotlin & Jetpack Compose** لترجمة نصوص ألعاب الـ Visual Novels والألعاب الأجنبية بنظام Transparent Overlay عائم ومباشر فوق شاشة اللعبة.

---

## الميزات المعمارية والتقنية

1. **Android 14+ MediaProjection Foreground Service:**
   - خدمة خلفية من نوع `foregroundServiceType="mediaProjection"`.
   - إشعار دائم مع إمكانية إيقاف الخدمة بلمسة واحدة.
2. **Zero-Disk In-RAM Screen Capture:**
   - التقاط الإطارات عبر `ImageReader` ومباشرة في الذاكرة العشوائية RAM دون حفظ أي صور على القرص الصلب نهائياً.
   - قص (Crop) فوري لمنطقة الحوار المحددة لتسريع المعالجة وتقليل استهلاك الموارد.
3. **Local Google ML Kit OCR Engine V2:**
   - دعم مباشر على الجهاز دون الحاجة لإنترنت لقراءة النصوص:
     - اليابانية (`text-recognition-japanese`)
     - الصينية (`text-recognition-chinese`)
     - الكورية (`text-recognition-korean`)
     - اللاتينية / الإنجليزية (`text-recognition-latin`)
4. **Context Engine & Spoiler Protection:**
   - تلخيص السياق دون إرسال كامل تاريخ الحوارات لتقليل تكلفة الـ Tokens.
   - حماية الحرق: الاعتماد فقط على النص الحالي وملفات الشخصيات المسجلة.
   - إجبار الذكاء الاصطناعي على مطابقة مسرد المصطلحات (Glossary).
   - Structured JSON Output:
     ```json
     {
       "speaker": "اسم المتحدث أو unknown",
       "tone": "نبرة الحديث",
       "translation": "الترجمة العربية الأدبية الفصيحة",
       "confidence": 0.95,
       "literal_meaning": "المعنى الحرفي",
       "literary_elements": ["استعارة...", "كناية..."],
       "references": ["مرجع ثقافي أو أدبي..."],
       "needs_review": false
     }
     ```
5. **WindowManager & Touch Passthrough:**
   - استخدام `FLAG_NOT_FOCUSABLE` و `FLAG_NOT_TOUCH_MODAL` لتمرير لمسات الأصابع مباشرة إلى اللعبة خلف الـ Overlay دون إعاقتها.
   - زر عائم قابل للسحب في أي موضع مع قفل الموضع (Lock Position).
   - إمكانية تخصيص حجم الخط وشفافية الصندوق وألوانه.
6. **Room Database & Jetpack DataStore:**
   - حفظ المشاريع، الشخصيات، المسرد، وسجل الحوارات.
   - نظام Cache سريع بالـ SHA-256 لمنع تكرار طلبات الترجمة للحوارات المتطابقة.

---

## كيفية البناء وتشغيل التطبيق (Build & Run)

### 1. فتح المشروع في Android Studio
1. افتح **Android Studio** (نسخة Ladybug / Iguana أو أحدث).
2. اختر **Open** وحدد مجلد `android/`.
3. انتظر اكتمال مزامنة Gradle Sync.

### 2. ضبط مفتاح Gemini API
أضف المفتاح في ملف `android/gradle.properties`:
```properties
GEMINI_API_KEY=AIzaSy...
```
أو يمكنك إدخاله مباشرة من شاشة الإعدادات داخل التطبيق بعد تثبيته.

### 3. بناء وتثبيت الـ APK
عبر سطر الأوامر:
```bash
./gradlew assembleDebug
```
أو اضغط **Run (Shift + F10)** لتثبيته مباشرة على هاتفك أو المحاكي.

---

## الصلاحيات المطلوبة:
- **Display Over Other Apps (`SYSTEM_ALERT_WINDOW`)**: لعرض الزر العائم وصندوق الترجمة الشفاف.
- **Screen Capture (`MediaProjection`)**: لالتقاط منطقة الحوار وتحليلها محلياً بـ OCR.
