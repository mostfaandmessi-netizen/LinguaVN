package com.linguavn.app.domain.context

import com.linguavn.app.data.local.entity.CharacterEntity
import com.linguavn.app.data.local.entity.GlossaryEntity
import com.linguavn.app.data.local.entity.HistoryEntity
import com.linguavn.app.domain.model.TranslationMode

object ContextEngine {

    fun buildTranslationPrompt(
        sourceText: String,
        sourceLanguageName: String,
        mode: TranslationMode,
        contextSummary: String,
        characters: List<CharacterEntity>,
        glossary: List<GlossaryEntity>,
        recentHistory: List<HistoryEntity>
    ): String {
        val characterBlock = if (characters.isNotEmpty()) {
            characters.joinToString("\n") { c ->
                "• [شخصية: ${c.name}] - الشخصية: ${c.personality} | الأسلوب: ${c.speakingStyle} | النبرة/الرسمية: ${c.formality} ${if (c.notes.isNotBlank()) "| ملاحظات: ${c.notes}" else ""}"
            }
        } else {
            "لم يتم تسجيل شخصيات محددة مسبقاً لهذا المشهد."
        }

        val glossaryBlock = if (glossary.isNotEmpty()) {
            glossary.joinToString("\n") { g ->
                "• \"${g.original}\" => \"${g.translation}\" ${if (g.notes.isNotBlank()) "(${g.notes})" else ""} ${if (g.isPreferred) "[ترجمة مفضلة ملزمة]" else ""}"
            }
        } else {
            "لا توجد مصطلحات مسرد خاصة مسجلة."
        }

        val historyBlock = if (recentHistory.isNotEmpty()) {
            recentHistory.takeLast(6).joinToString("\n") { h ->
                "• [${h.speaker}]: ${h.originalText} => ${h.arabicTranslation}"
            }
        } else {
            "هذا أول حوار في الجلسة أو لا توجد سجلات سابقة."
        }

        return """
أنت محرك الترجمة الأدبي الذكي الحصري لتطبيق LinguaVN، والمكلف بترجمة ألعاب الروايات المرئية (Visual Novels) بدقة سياقية فائقة إلى اللغة العربية الأدبية الطبيعية.

=== القواعد الإلزامية الصارمة ===
1. [الأسلوب المختار]: ${mode.displayName} - ${mode.promptInstruction}
2. [حماية الحرق (Spoiler Protection)]: ممنوع قطعاً استخدام أي معلومات أو أحداث مستقبلية من العمل. اعتمد حصراً على النص الحالي والحوارات السابقة المسجلة.
3. [المسرد]: التزم التزاماً كاملاً بترجمات المسرد الإلزامية دون أي تبديل.
4. [الشخصيات]: إذا تطابق المتحدث مع إحدى الشخصيات، صغ حواره بما يعكس شخصيته ونبرته وأسلوب حديثه بدقة.
5. [المتحدث المجهول]: إذا لم يظهر اسم المتحدث بوضوح في النص الحالي، اجعل قيمة "speaker": "unknown". لا تخترع أسماء.
6. [البلاغة]: لا تترجم التعبيرات الاصطلاحية (Idioms) حرفياً؛ استبدلها بمرادف أدبي عربي بليغ ومناسب.
7. [الأمانة السياقية]: لا تحذف معنى موجوداً ولا تضف استطرادات زائفة غير موجودة في النص.

=== السياق العام للقصة ===
${contextSummary.ifBlank { "رواية مرئية / لعبة يابانية تركز على البلاغة والتفاعل القصصي." }}

=== ملفات الشخصيات المسجلة ===
$characterBlock

=== المسرد والمصطلحات المعتمدة ===
$glossaryBlock

=== آخر الحوارات السابقة فوراً ===
$historyBlock

=== النص المطلوب ترجمته الآن ($sourceLanguageName) ===
\"\"\"
$sourceText
\"\"\"

أرجع النتيجة حصراً بهيكل JSON التالي دون أي نصوص إضافية:
{
  "speaker": "اسم المتحدث أو unknown",
  "tone": "النبرة الانفعالية للحوار",
  "translation": "الترجمة العربية الأدبية الطبيعية",
  "confidence": 0.95,
  "literal_meaning": "المعنى الحرفي الموجز للمقارنة",
  "literary_elements": ["استعارة كذا", "تشبيه كذا"],
  "references": ["مرجع ثقافي أو أدبي إن وجد"],
  "needs_review": false
}
""".trimIndent()
    }
}
