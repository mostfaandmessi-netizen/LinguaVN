package com.linguavn.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.linguavn.app.LinguaApplication
import com.linguavn.app.data.local.entity.*
import com.linguavn.app.domain.model.OverlaySettings
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    private val repository = LinguaApplication.instance.repository

    val projects = repository.getAllProjects().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _selectedProjectId = MutableStateFlow<Long?>(null)
    val selectedProjectId = _selectedProjectId.asStateFlow()

    val overlaySettings = repository.overlaySettings.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        OverlaySettings()
    )

    val geminiApiKey = repository.geminiApiKey.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ""
    )

    init {
        // Automatically seed initial Visual Novel project if none exists
        viewModelScope.launch {
            repository.getAllProjects().firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    seedSakuraNoUta()
                } else {
                    _selectedProjectId.value = list.first().id
                }
            }
        }
    }

    private suspend fun seedSakuraNoUta() {
        val projId = repository.insertProject(
            ProjectEntity(
                name = "Sakura no Uta - 素晴らしき日々",
                originalLang = "ja",
                targetLang = "ar",
                translationMode = "LITERARY_NATURAL",
                contextSummary = "رواية مرئية فلسفية وفنية تستكشف مفهوم الجمال، الفن، الشعر، وفناء الوجود تحت أزهار الكرز المتفتحة.",
                regionX = 0.05f,
                regionY = 0.70f,
                regionWidth = 0.90f,
                regionHeight = 0.25f
            )
        )
        _selectedProjectId.value = projId

        // Add Characters
        repository.insertCharacter(
            CharacterEntity(
                projectId = projId,
                name = "Kusanagi Naoya",
                personality = "هادئ، فنان متأمل، يحمل عبء ماضيه الفني بوقار",
                speakingStyle = "موجز، فصيح، عميق بنبرة حنين ورزانة",
                formality = "مهذب ومتزن",
                relationship = "بطل العمل والرسام الموهوب",
                notes = "لا يتحدث بكثرة إلا عند مناقشة الفن أو لوحات والده."
            )
        )
        repository.insertCharacter(
            CharacterEntity(
                projectId = projId,
                name = "Misakura Rin",
                personality = "شابة غامضة، حساسة، ذات روح بوهيمية",
                speakingStyle = "شاعري، رقيق، فيه مسحة حزن خفيفة",
                formality = "عفوي ودافئ",
                relationship = "صديقة الطفولة وملهمة الرسم",
                notes = "تستخدم مجازات الطبيعة وتساقط بتلات الكرز."
            )
        )

        // Add Glossary
        repository.insertGlossary(
            GlossaryEntity(
                projectId = projId,
                original = "サクラノ詩",
                translation = "قصيدة الكرز",
                notes = "المفهوم الفلسفي المحوري للعمل",
                isPreferred = true
            )
        )
        repository.insertGlossary(
            GlossaryEntity(
                projectId = projId,
                original = "美の探求",
                translation = "التماس الجمال المطلق",
                notes = "مفهوم فني يتكرر في اللوحات",
                isPreferred = true
            )
        )
    }

    fun selectProject(id: Long) {
        _selectedProjectId.value = id
        viewModelScope.launch {
            repository.setActiveProjectId(id)
        }
    }

    fun createProject(name: String, summary: String, mode: String, originalLang: String) {
        viewModelScope.launch {
            val id = repository.insertProject(
                ProjectEntity(
                    name = name,
                    contextSummary = summary,
                    translationMode = mode,
                    originalLang = originalLang
                )
            )
            _selectedProjectId.value = id
        }
    }

    fun updateOverlaySettings(settings: OverlaySettings) {
        viewModelScope.launch {
            repository.saveOverlaySettings(settings)
        }
    }

    fun updateApiKey(key: String) {
        viewModelScope.launch {
            repository.setGeminiApiKey(key)
        }
    }
}
