package com.linguavn.app.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF090D16)
val SurfaceDark = Color(0xFF0F172A)
val CardDark = Color(0xFF1E293B)
val PrimaryIndigo = Color(0xFF6366F1)
val AccentCyan = Color(0xFF38BDF8)
val AccentAmber = Color(0xFFFBBF24)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val BorderSubtle = Color(0xFF334155)
