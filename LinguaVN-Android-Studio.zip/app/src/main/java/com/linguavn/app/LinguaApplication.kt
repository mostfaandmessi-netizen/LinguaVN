package com.linguavn.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.linguavn.app.data.local.LinguaDatabase
import com.linguavn.app.data.local.PreferencesManager
import com.linguavn.app.data.repository.LinguaRepository

class LinguaApplication : Application() {

    lateinit var database: LinguaDatabase
        private set

    lateinit var preferencesManager: PreferencesManager
        private set

    lateinit var repository: LinguaRepository
        private set

    companion object {
        const val OVERLAY_CHANNEL_ID = "lingua_vn_overlay_channel"
        lateinit var instance: LinguaApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        database = LinguaDatabase.getDatabase(this)
        preferencesManager = PreferencesManager(this)
        repository = LinguaRepository(database.linguaDao(), preferencesManager)

        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.notification_channel_name)
            val descriptionText = getString(R.string.notification_channel_desc)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(OVERLAY_CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
