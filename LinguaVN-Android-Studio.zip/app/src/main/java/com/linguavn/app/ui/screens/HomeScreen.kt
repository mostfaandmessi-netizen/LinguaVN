package com.linguavn.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavn.app.data.local.entity.ProjectEntity
import com.linguavn.app.ui.theme.*

@Composable
fun HomeScreen(
    projects: List<ProjectEntity>,
    selectedProjectId: Long?,
    onSelectProject: (Long) -> Unit,
    onStartOverlay: () -> Unit,
    onNavigateCharacters: (Long) -> Unit,
    onNavigateGlossary: (Long) -> Unit,
    onNavigateHistory: (Long) -> Unit,
    onNavigateSettings: () -> Unit,
    onNewProject: () -> Unit
) {
    val currentProject = projects.find { it.id == selectedProjectId } ?: projects.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        // App Title & Tagline
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "LinguaVN",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "\"ترجم العمل كما يُفهم، لا كما تُكتب كلماته.\"",
            fontSize = 14.sp,
            color = AccentCyan,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Active Project Indicator / Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "المشروع النشط:",
                fontSize = 13.sp,
                color = TextSecondary,
                fontWeight = FontWeight.SemiBold
            )
            TextButton(onClick = onNewProject) {
                Icon(Icons.Default.Add, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("مشروع جديد", color = AccentCyan, fontSize = 13.sp)
            }
        }

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = SurfaceDark,
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(BorderSubtle))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = currentProject?.name ?: "لم يتم اختيار مشروع",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                if (currentProject != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentProject.contextSummary.ifBlank { "لا يوجد سياق مخصص" },
                        fontSize = 13.sp,
                        color = TextSecondary,
                        maxLines = 2
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Primary Start Overlay Action Button
        Button(
            onClick = onStartOverlay,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "بدء الترجمة الفورية (Start Overlay)",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "الأقسام الرئيسية",
            fontSize = 14.sp,
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Minimal Clean Navigation List
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            NavMenuItem(
                title = "الشخصيات (Characters)",
                subtitle = "إدارة أسلوب الحديث، النبرة، والرسمية",
                icon = Icons.Default.People,
                onClick = { currentProject?.let { onNavigateCharacters(it.id) } }
            )
            NavMenuItem(
                title = "المسرد (Glossary)",
                subtitle = "المصطلحات الثابتة والترجمات المفضلة",
                icon = Icons.Default.MenuBook,
                onClick = { currentProject?.let { onNavigateGlossary(it.id) } }
            )
            NavMenuItem(
                title = "سجل الحوارات (History)",
                subtitle = "استرجاع الحوارات السابقة والتعديلات اليدوية",
                icon = Icons.Default.History,
                onClick = { currentProject?.let { onNavigateHistory(it.id) } }
            )
            NavMenuItem(
                title = "الإعدادات (Settings)",
                subtitle = "الشفافية، حجم الخط، الوضع التلقائي ومفتاح Gemini",
                icon = Icons.Default.Settings,
                onClick = onNavigateSettings
            )
        }
    }
}

@Composable
fun NavMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = SurfaceDark
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = PrimaryIndigo, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(text = subtitle, fontSize = 12.sp, color = TextSecondary)
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = BorderSubtle)
        }
    }
}
