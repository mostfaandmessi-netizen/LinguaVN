package com.linguavn.app.domain.model

import java.io.Serializable

enum class TranslationMode(val displayName: String, val promptInstruction: String) {
    LITERARY_NATURAL(
        "أدبي + طبيعي (الافتراضي)",
        "أسلوب أدبي رفيع بلغة عربية فصيحة وسلسة وممتعة للقراءة مثل الروايات العالمية الفاخرة."
    ),
    NATURAL(
        "طبيعي ومعاصر",
        "أسلوب حواري طبيعي وسلس يماثل المحادثات الواقعية دون تكلف."
    ),
    LITERARY(
        "أدبي كلاسيكي",
        "أسلوب أدبي كلاسيكي فصيح بمفردات عميقة وبلاغة عالية."
    ),
    ACCURATE(
        "دقيق ومطابق",
        "ترجمة أمينة ومطابقة للغاية لمعنى كل جملة دون أي تصرف زائد."
    ),
    CINEMATIC(
        "سينمائي مشوق",
        "أسلوب درامي مشحون بالعواطف والتوتر يناسب المشاهد السينمائية ولحظات الذروة."
    ),
    ORIGINAL_STYLE(
        "محافظ على النبرة الأصلية",
        "التزام حرفي بنبرة العمل الأصلية وطريقة تحدث الشخصية بالضبط."
    )
}

enum class SupportedLanguage(val code: String, val label: String) {
    JAPANESE("ja", "اليابانية (日本語)"),
    ENGLISH("en", "الإنجليزية (English)"),
    CHINESE("zh", "الصينية (中文)"),
    KOREAN("ko", "الكورية (한국어)")
}

data class DialogueRegion(
    val xPercent: Float = 0.05f,
    val yPercent: Float = 0.65f,
    val widthPercent: Float = 0.90f,
    val heightPercent: Float = 0.30f
) : Serializable

data class TranslationResult(
    val speaker: String = "unknown",
    val tone: String = "عادي",
    val translation: String = "",
    val confidence: Double = 1.0,
    val literalMeaning: String = "",
    val literaryElements: List<String> = emptyList(),
    val references: List<String> = emptyList(),
    val needsReview: Boolean = false,
    val cached: Boolean = false
) : Serializable

data class ExplainResult(
    val directMeaning: String,
    val impliedSubtext: String,
    val tone: String,
    val metaphorAndIdiom: String,
    val culturalOrPhilosophicalRef: String
) : Serializable

data class OverlaySettings(
    val fontSizeSp: Float = 17f,
    val backgroundOpacity: Float = 0.82f,
    val textColorHex: String = "#F8FAFC",
    val backgroundColorHex: String = "#0F172A",
    val lockPosition: Boolean = false,
    val autoMode: Boolean = false,
    val autoCaptureIntervalMs: Long = 1800L
) : Serializable
