package com.linguavn.app.data.repository

import com.linguavn.app.data.local.dao.LinguaDao
import com.linguavn.app.data.local.entity.*
import com.linguavn.app.data.local.PreferencesManager
import com.linguavn.app.data.remote.GeminiApiService
import com.linguavn.app.domain.context.ContextEngine
import com.linguavn.app.domain.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import org.json.JSONObject

class LinguaRepository(
    private val dao: LinguaDao,
    private val preferencesManager: PreferencesManager
) {
    private val geminiService = GeminiApiService {
        preferencesManager.geminiApiKey.firstOrNull() ?: ""
    }

    // Projects
    fun getAllProjects(): Flow<List<ProjectEntity>> = dao.getAllProjects()
    suspend fun getProject(id: Long): ProjectEntity? = dao.getProjectById(id)
    suspend fun insertProject(project: ProjectEntity): Long = dao.insertProject(project)
    suspend fun updateProject(project: ProjectEntity) = dao.updateProject(project)
    suspend fun deleteProject(project: ProjectEntity) = dao.deleteProject(project)

    // Characters
    fun getCharacters(projectId: Long): Flow<List<CharacterEntity>> = dao.getCharactersByProject(projectId)
    suspend fun insertCharacter(character: CharacterEntity): Long = dao.insertCharacter(character)
    suspend fun deleteCharacter(character: CharacterEntity) = dao.deleteCharacter(character)

    // Glossary
    fun getGlossary(projectId: Long): Flow<List<GlossaryEntity>> = dao.getGlossaryByProject(projectId)
    suspend fun insertGlossary(term: GlossaryEntity): Long = dao.insertGlossary(term)
    suspend fun deleteGlossary(term: GlossaryEntity) = dao.deleteGlossary(term)

    // History
    fun getHistory(projectId: Long): Flow<List<HistoryEntity>> = dao.getHistoryByProject(projectId)
    suspend fun updateCorrection(historyId: Long, correction: String, projectId: Long, originalText: String) {
        dao.updateHistoryCorrection(historyId, correction)
        // Also save to glossary as preferred translation
        dao.insertGlossary(
            GlossaryEntity(
                projectId = projectId,
                original = originalText,
                translation = correction,
                notes = "ترجمة يدوية مفضلة من المستخدم",
                isPreferred = true
            )
        )
    }

    // Preferences & Settings
    val overlaySettings: Flow<OverlaySettings> = preferencesManager.overlaySettings
    suspend fun saveOverlaySettings(settings: OverlaySettings) = preferencesManager.updateOverlaySettings(settings)

    val activeProjectId: Flow<Long?> = preferencesManager.activeProjectId
    suspend fun setActiveProjectId(id: Long) = preferencesManager.setActiveProjectId(id)

    suspend fun setGeminiApiKey(key: String) = preferencesManager.setGeminiApiKey(key)
    val geminiApiKey: Flow<String?> = preferencesManager.geminiApiKey

    // Central Translation Orchestrator
    suspend fun translateDialogue(
        projectId: Long,
        sourceText: String,
        sourceLanguage: SupportedLanguage
    ): TranslationResult {
        val trimmed = sourceText.trim()
        if (trimmed.isEmpty()) {
            return TranslationResult(
                speaker = "unknown",
                tone = "تنبيه",
                translation = "لم يتم التقاط أي نص.",
                confidence = 1.0
            )
        }

        val project = dao.getProjectById(projectId) ?: ProjectEntity(name = "مشروع مؤقت")
        val mode = try {
            TranslationMode.valueOf(project.translationMode)
        } catch (e: Exception) {
            TranslationMode.LITERARY_NATURAL
        }

        // 1. Check Cache first to prevent unnecessary Gemini API cost
        val hash = geminiService.computeHash(trimmed, mode.name, projectId)
        val cached = dao.getCachedTranslation(hash)
        if (cached != null) {
            val json = JSONObject(cached.jsonResult)
            return TranslationResult(
                speaker = json.optString("speaker", "unknown"),
                tone = json.optString("tone", "عادي"),
                translation = json.optString("translation", ""),
                confidence = json.optDouble("confidence", 1.0),
                literalMeaning = json.optString("literal_meaning", ""),
                needsReview = false,
                cached = true
            )
        }

        // 2. Build Context-Aware Prompt with Character Profiles, Glossary, and Context Summary
        val characters = dao.getCharactersList(projectId)
        val glossary = dao.getGlossaryList(projectId)
        val recentHistory = dao.getRecentHistory(projectId, 6)

        val prompt = ContextEngine.buildTranslationPrompt(
            sourceText = trimmed,
            sourceLanguageName = sourceLanguage.label,
            mode = mode,
            contextSummary = project.contextSummary,
            characters = characters,
            glossary = glossary,
            recentHistory = recentHistory
        )

        // 3. Call Gemini API
        val result = geminiService.translateWithGemini(prompt)

        // 4. Save to History & Cache if successful
        if (result.translation.isNotBlank() && !result.needsReview) {
            dao.insertHistory(
                HistoryEntity(
                    projectId = projectId,
                    originalText = trimmed,
                    arabicTranslation = result.translation,
                    speaker = result.speaker,
                    tone = result.tone,
                    context = project.contextSummary
                )
            )

            val jsonToCache = JSONObject().apply {
                put("speaker", result.speaker)
                put("tone", result.tone)
                put("translation", result.translation)
                put("confidence", result.confidence)
                put("literal_meaning", result.literalMeaning)
            }
            dao.insertCache(
                TranslationCacheEntity(
                    textHash = hash,
                    originalText = trimmed,
                    jsonResult = jsonToCache.toString()
                )
            )
        }

        return result
    }

    suspend fun explainDialogue(
        originalText: String,
        arabicTranslation: String,
        speaker: String,
        contextSummary: String
    ): ExplainResult {
        return geminiService.explainDialogue(originalText, arabicTranslation, speaker, contextSummary)
    }
}
