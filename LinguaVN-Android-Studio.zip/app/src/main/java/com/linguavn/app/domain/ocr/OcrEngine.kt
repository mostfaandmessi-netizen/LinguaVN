package com.linguavn.app.domain.ocr

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.linguavn.app.domain.model.DialogueRegion
import com.linguavn.app.domain.model.SupportedLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCancellableCoroutine

interface OcrEngine {
    suspend fun extractText(
        fullBitmap: Bitmap,
        language: SupportedLanguage,
        dialogueRegion: DialogueRegion?
    ): String

    fun release()
}

class MlKitOcrEngine : OcrEngine {

    private var japaneseRecognizer: TextRecognizer? = null
    private var chineseRecognizer: TextRecognizer? = null
    private var koreanRecognizer: TextRecognizer? = null
    private var latinRecognizer: TextRecognizer? = null

    private fun getRecognizer(language: SupportedLanguage): TextRecognizer {
        return when (language) {
            SupportedLanguage.JAPANESE -> {
                if (japaneseRecognizer == null) {
                    japaneseRecognizer = TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
                }
                japaneseRecognizer!!
            }
            SupportedLanguage.CHINESE -> {
                if (chineseRecognizer == null) {
                    chineseRecognizer = TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
                }
                chineseRecognizer!!
            }
            SupportedLanguage.KOREAN -> {
                if (koreanRecognizer == null) {
                    koreanRecognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                }
                koreanRecognizer!!
            }
            SupportedLanguage.ENGLISH -> {
                if (latinRecognizer == null) {
                    latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                }
                latinRecognizer!!
            }
        }
    }

    override suspend fun extractText(
        fullBitmap: Bitmap,
        language: SupportedLanguage,
        dialogueRegion: DialogueRegion?
    ): String = withContext(Dispatchers.Default) {
        val croppedBitmap = if (dialogueRegion != null) {
            cropBitmap(fullBitmap, dialogueRegion)
        } else {
            fullBitmap
        }

        val recognizer = getRecognizer(language)
        val image = InputImage.fromBitmap(croppedBitmap, 0)

        suspendCancellableCoroutine { continuation ->
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    // Clean up and join lines seamlessly
                    val rawText = visionText.text.trim()
                    // Japanese/Chinese formatting: remove unwanted line break spaces
                    val cleanedText = if (language == SupportedLanguage.JAPANESE || language == SupportedLanguage.CHINESE) {
                        rawText.replace("\n", "").replace(" ", "")
                    } else {
                        rawText.replace("\n", " ")
                    }
                    continuation.resume(cleanedText)
                }
                .addOnFailureListener { exception ->
                    continuation.resumeWithException(exception)
                }
        }
    }

    private fun cropBitmap(source: Bitmap, region: DialogueRegion): Bitmap {
        val startX = (source.width * region.xPercent).toInt().coerceIn(0, source.width - 1)
        val startY = (source.height * region.yPercent).toInt().coerceIn(0, source.height - 1)
        val cropW = (source.width * region.widthPercent).toInt().coerceIn(1, source.width - startX)
        val cropH = (source.height * region.heightPercent).toInt().coerceIn(1, source.height - startY)

        return Bitmap.createBitmap(source, startX, startY, cropW, cropH)
    }

    override fun release() {
        japaneseRecognizer?.close()
        chineseRecognizer?.close()
        koreanRecognizer?.close()
        latinRecognizer?.close()
    }
}
