package com.linguavn.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.linguavn.app.service.OverlayService
import com.linguavn.app.ui.screens.*
import com.linguavn.app.ui.theme.LinguaVNTheme
import com.linguavn.app.ui.theme.SurfaceDark
import com.linguavn.app.ui.theme.TextPrimary
import com.linguavn.app.viewmodel.MainViewModel

enum class Screen {
    HOME,
    CHARACTERS,
    GLOSSARY,
    HISTORY,
    SETTINGS
}

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startOverlayService(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "تم إلغاء صلاحية التقاط الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (checkOverlayPermission()) {
            requestMediaProjection()
        } else {
            Toast.makeText(this, "يرجى منح صلاحية الظهور فوق التطبيقات لتشغيل الـ Overlay", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            LinguaVNTheme {
                var currentScreen by remember { mutableStateOf(Screen.HOME) }
                val projects by viewModel.projects.collectAsState()
                val selectedProjectId by viewModel.selectedProjectId.collectAsState()

                var showNewProjectDialog by remember { mutableStateOf(false) }

                when (currentScreen) {
                    Screen.HOME -> HomeScreen(
                        projects = projects,
                        selectedProjectId = selectedProjectId,
                        onSelectProject = { viewModel.selectProject(it) },
                        onStartOverlay = { initiateOverlayLaunch() },
                        onNavigateCharacters = { currentScreen = Screen.CHARACTERS },
                        onNavigateGlossary = { currentScreen = Screen.GLOSSARY },
                        onNavigateHistory = { currentScreen = Screen.HISTORY },
                        onNavigateSettings = { currentScreen = Screen.SETTINGS },
                        onNewProject = { showNewProjectDialog = true }
                    )
                    Screen.CHARACTERS -> CharactersScreen(
                        projectId = selectedProjectId ?: 1L,
                        onBack = { currentScreen = Screen.HOME }
                    )
                    Screen.GLOSSARY -> GlossaryScreen(
                        projectId = selectedProjectId ?: 1L,
                        onBack = { currentScreen = Screen.HOME }
                    )
                    Screen.HISTORY -> HistoryScreen(
                        projectId = selectedProjectId ?: 1L,
                        onBack = { currentScreen = Screen.HOME }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        onBack = { currentScreen = Screen.HOME }
                    )
                }

                if (showNewProjectDialog) {
                    NewProjectDialog(
                        onDismiss = { showNewProjectDialog = false },
                        onCreate = { name, summary, mode, lang ->
                            viewModel.createProject(name, summary, mode, lang)
                            showNewProjectDialog = false
                        }
                    )
                }
            }
        }
    }

    private fun checkOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun initiateOverlayLaunch() {
        if (!checkOverlayPermission()) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            requestMediaProjection()
        }
    }

    private fun requestMediaProjection() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun startOverlayService(resultCode: Int, data: Intent) {
        val activeProj = viewModel.selectedProjectId.value ?: 1L
        val serviceIntent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
            putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
            putExtra(OverlayService.EXTRA_RESULT_DATA, data)
            putExtra(OverlayService.EXTRA_PROJECT_ID, activeProj)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }

        Toast.makeText(this, "تم تشغيل LinguaVN! افتح لعبتك الآن.", Toast.LENGTH_LONG).show()
        moveTaskToBack(true)
    }
}

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, summary: String, mode: String, lang: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var selectedMode by remember { mutableStateOf("LITERARY_NATURAL") }
    var selectedLang by remember { mutableStateOf("ja") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إنشاء مشروع Visual Novel جديد", color = TextPrimary) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم العمل (مثال: Sakura no Uta)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = summary,
                    onValueChange = { summary = it },
                    label = { Text("السياق العام للقصة (بدون حرق)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onCreate(name, summary, selectedMode, selectedLang)
                    }
                }
            ) { Text("إنشاء المشروع") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        },
        containerColor = SurfaceDark
    )
}
