package com.linguavn.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavn.app.LinguaApplication
import com.linguavn.app.data.local.entity.HistoryEntity
import com.linguavn.app.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    projectId: Long,
    onBack: () -> Unit
) {
    val repository = LinguaApplication.instance.repository
    val historyFlow = remember(projectId) { repository.getHistory(projectId) }
    val historyList by historyFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var editingItem by remember { mutableStateOf<HistoryEntity?>(null) }
    var correctedText by remember { mutableStateOf("") }

    val dateFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سجل الحوارات المترجمة", color = TextPrimary, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        containerColor = BgDark
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (historyList.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("لم تتم ترجمة أي حوارات بعد في هذا المشروع.", color = TextSecondary, fontSize = 14.sp)
                    }
                }
            }

            items(historyList, key = { it.id }) { item ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceDark
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (item.speaker != "unknown") item.speaker else "مجهول",
                                    color = AccentCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(dateFormat.format(Date(item.timestamp)), color = TextSecondary, fontSize = 11.sp)
                            }

                            IconButton(
                                onClick = {
                                    editingItem = item
                                    correctedText = item.userCorrection ?: item.arabicTranslation
                                },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "تعديل وتفضيل الترجمة", tint = AccentAmber, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(item.originalText, color = TextSecondary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.userCorrection ?: item.arabicTranslation,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )

                        if (item.userCorrection != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("✓ تم حفظ تعديلك كترجمة مفضلة بالمسرد", color = Color(0xFF34D399), fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        editingItem?.let { current ->
            AlertDialog(
                onDismissRequest = { editingItem = null },
                title = { Text("تعديل الترجمة وحفظها في المسرد", color = TextPrimary) },
                text = {
                    Column {
                        Text("النص الأصلي: ${current.originalText}", color = TextSecondary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = correctedText,
                            onValueChange = { correctedText = it },
                            label = { Text("صيغة الترجمة العربية المفضلة") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            scope.launch {
                                repository.updateCorrection(current.id, correctedText, projectId, current.originalText)
                                editingItem = null
                            }
                        }
                    ) { Text("تأكيد وتفضيل") }
                },
                dismissButton = {
                    TextButton(onClick = { editingItem = null }) { Text("إلغاء") }
                },
                containerColor = SurfaceDark
            )
        }
    }
}
