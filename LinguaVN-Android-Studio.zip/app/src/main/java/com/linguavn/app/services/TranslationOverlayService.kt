package com.linguavn.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.linguavn.app.MainActivity
import com.linguavn.app.service.lifecycle.ServiceLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlin.math.max
import kotlin.math.min

/**
 * TranslationOverlayService
 * -----------------------------------------------------------------------------------
 * Foreground Service في مسار (com.linguavn.app.services) مخصص لإدارة الزر العائم (Floating Button)
 * وشاشة الترجمة الفوقية (Overlay Window) لألعاب الروايات المرئية (Visual Novels).
 *
 * الخصائص المعمارية الأساسية:
 * 1. Foreground Service مع دعم نظام إشعارات Android 14+ (FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION).
 * 2. ربط الـ ComposeView بدورة حياة الـ Service الكاملة (LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner).
 * 3. إدارة النوافذ عبر WindowManager مع تقنية تمرير اللمسات (Touch Passthrough):
 *    - FLAG_NOT_FOCUSABLE: يضمن عدم اعتراض زر الرجوع أو لوحة المفاتيح.
 *    - FLAG_NOT_TOUCH_MODAL: يسمح بمرور اللمسات خارج الزر العائم إلى اللعبة المشغلة في الخلفية.
 *    - وضع FLAG_NOT_TOUCHABLE عند تفعيل التمرير الكامل للّمس فوق صندوق الترجمة.
 */
class TranslationOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.linguavn.app.services.ACTION_START"
        const val ACTION_STOP = "com.linguavn.app.services.ACTION_STOP"
        const val ACTION_TOGGLE_PASSTHROUGH = "com.linguavn.app.services.ACTION_TOGGLE_PASSTHROUGH"

        const val CHANNEL_ID = "lingua_vn_overlay_channel"
        const val NOTIFICATION_ID = 9022
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var windowManager: WindowManager
    private val lifecycleOwner = ServiceLifecycleOwner()

    // ComposeViews المدارة بواسطة WindowManager
    private var floatingButtonView: ComposeView? = null
    private var translationOverlayView: ComposeView? = null

    // بارامترات النوافذ
    private var floatingParams: WindowManager.LayoutParams? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    // أبعاد الشاشة
    private var screenWidth = 1080
    private var screenHeight = 2400

    // حالات الواجهة التفاعلية (Reactive Compose States)
    private val isTranslating = mutableStateOf(false)
    private val isOverlayVisible = mutableStateOf(true)
    private val isLocked = mutableStateOf(false)
    private val isTouchPassthrough = mutableStateOf(false)
    private val currentSpeaker = mutableStateOf("الراوي")
    private val currentTranslation = mutableStateOf("انقر على الزر العائم للترجمة الفورية لحوار اللعبة...")

    override fun onCreate() {
        super.onCreate()
        lifecycleOwner.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        updateScreenMetrics()
        initNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        when (intent.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PASSTHROUGH -> {
                togglePassthroughMode()
            }
            ACTION_START, null -> {
                startForegroundNotification()
                if (floatingButtonView == null) {
                    attachFloatingButton()
                    attachTranslationOverlay()
                }
            }
        }

        return START_STICKY
    }

    private fun updateScreenMetrics() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    /**
     * إطلاق Foreground Service مع الإشعار الدائم
     */
    private fun startForegroundNotification() {
        val stopIntent = Intent(this, TranslationOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LinguaVN - خدمة الزر العائم")
            .setContentText("الزر العائم نشط فوق شاشة اللعبة لتسهيل الترجمة الفورية")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(mainPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة الترجمة العائمة LinguaVN",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار تشغيل خدمة الزر العائم فوق التطبيقات والألعاب"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * ربط الزر العائم بـ ComposeView وإضافته للـ WindowManager
     * مع تطبيق أعلام تمرير اللمسات (FLAG_NOT_FOCUSABLE و FLAG_NOT_TOUCH_MODAL)
     */
    private fun attachFloatingButton() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // إعدادات WindowManager.LayoutParams لضمان تمرير اللمسات بدقة للعبة:
        // - FLAG_NOT_FOCUSABLE: يمنع حجب مفاتيح النظام (زر الرجوع / لوحة المفاتيح).
        // - FLAG_WATCH_OUTSIDE_TOUCH: يستمع لأحداث اللمس خارج النافذة (ACTION_OUTSIDE) مع تمريرها فورياً للعبة.
        // - FLAG_NOT_TOUCH_MODAL: يسمح بمرور أحداث اللمس خارج حدود الزر إلى اللعبة بالأسفل.
        floatingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 360
        }

        floatingButtonView = ComposeView(this).apply {
            // ربط دورة حياة Compose بالـ Service
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            // الاستماع لأحداث اللمس الخارجية لتأكيد تمرير اللمسات بنجاح إلى اللعبة
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_OUTSIDE) {
                    // لمسة خارج الزر العائم مرت مباشرة إلى شاشة اللعبة
                    true
                } else {
                    false
                }
            }

            setContent {
                FloatingButtonView(
                    isTranslating = isTranslating.value,
                    isOverlayVisible = isOverlayVisible.value,
                    isLocked = isLocked.value,
                    isTouchPassthrough = isTouchPassthrough.value,
                    onTranslateClick = { triggerMockTranslation() },
                    onToggleOverlay = { isOverlayVisible.value = !isOverlayVisible.value },
                    onToggleLock = { isLocked.value = !isLocked.value },
                    onTogglePassthrough = { togglePassthroughMode() },
                    onDragAmount = { dx, dy -> handleDrag(dx, dy) }
                )
            }
        }

        windowManager.addView(floatingButtonView, floatingParams)
    }

    /**
     * ربط شريط الترجمة بـ ComposeView وإضافته للـ WindowManager
     */
    private fun attachTranslationOverlay() {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            computeOverlayFlags(isTouchPassthrough.value),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 60
        }

        translationOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            // التقاط أحداث اللمس خارج نافذة الترجمة
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_OUTSIDE) {
                    true
                } else {
                    false
                }
            }

            setContent {
                TranslationOverlayView(
                    isVisible = isOverlayVisible.value,
                    isTouchPassthrough = isTouchPassthrough.value,
                    speaker = currentSpeaker.value,
                    translation = currentTranslation.value,
                    isTranslating = isTranslating.value,
                    onClose = { isOverlayVisible.value = false },
                    onRetranslate = { triggerMockTranslation() },
                    onTogglePassthrough = { togglePassthroughMode() }
                )
            }
        }

        windowManager.addView(translationOverlayView, overlayParams)
    }

    /**
     * حساب أعلام الـ WindowManager لنافذة الترجمة الفوقية:
     * - FLAG_NOT_FOCUSABLE: عدم أخذ التركيز
     * - FLAG_WATCH_OUTSIDE_TOUCH: مراقبة وتمرير اللمسات الواقعة خارج الصندوق للعبة
     * - FLAG_NOT_TOUCHABLE: عند تفعيل وضع التمرير الشفاف لنقر الحوارات دون اعتراض
     */
    private fun computeOverlayFlags(passthrough: Boolean): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        if (passthrough) {
            // يسمح بمرور اللمس عبر الصندوق لتقديم النص في اللعبة
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return flags
    }

    private fun togglePassthroughMode() {
        val newPassthrough = !isTouchPassthrough.value
        isTouchPassthrough.value = newPassthrough

        overlayParams?.let { params ->
            params.flags = computeOverlayFlags(newPassthrough)
            translationOverlayView?.let { view ->
                windowManager.updateViewLayout(view, params)
            }
        }
    }

    private fun handleDrag(dx: Float, dy: Float) {
        if (isLocked.value || floatingParams == null || floatingButtonView == null) return

        floatingParams?.let { params ->
            val newX = params.x + dx.toInt()
            val newY = params.y + dy.toInt()

            params.x = max(0, min(newX, screenWidth - 160))
            params.y = max(40, min(newY, screenHeight - 200))

            windowManager.updateViewLayout(floatingButtonView, params)
        }
    }

    private fun triggerMockTranslation() {
        isTranslating.value = true
        isOverlayVisible.value = true

        floatingButtonView?.postDelayed({
            isTranslating.value = false
            currentSpeaker.value = "أوكابي رينتارو"
            currentTranslation.value = "الخيار لم يكن يوماً مقدراً مسبقاً، إنه خيار بوابة ستاينز!"
        }, 1100)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleOwner.onDestroy()
        serviceScope.cancel()

        try {
            floatingButtonView?.let { windowManager.removeView(it) }
            translationOverlayView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        floatingButtonView = null
        translationOverlayView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

/* =============================================================================
 * واجهات Jetpack Compose للزر العائم وشريط الحوار
 * ============================================================================= */

@Composable
fun FloatingButtonView(
    isTranslating: Boolean,
    isOverlayVisible: Boolean,
    isLocked: Boolean,
    isTouchPassthrough: Boolean,
    onTranslateClick: () -> Unit,
    onToggleOverlay: () -> Unit,
    onToggleLock: () -> Unit,
    onTogglePassthrough: () -> Unit,
    onDragAmount: (Float, Float) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    val buttonScale by animateFloatAsState(
        targetValue = if (isTranslating) 1.14f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "buttonScale"
    )

    Box(
        modifier = Modifier
            .wrapContentSize()
            .pointerInput(isLocked) {
                if (!isLocked) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragAmount(dragAmount.x, dragAmount.y)
                    }
                }
            }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // شريط الأدوات السريع عند التوسيع
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xEE0F172A),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .border(1.dp, Color(0x446366F1), RoundedCornerShape(16.dp))
                        .padding(4.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(4.dp)
                    ) {
                        IconButton(
                            onClick = onToggleOverlay,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isOverlayVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "إظهار/إخفاء اللوحة",
                                tint = if (isOverlayVisible) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                            )
                        }

                        IconButton(
                            onClick = onToggleLock,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "قفل الموضع",
                                tint = if (isLocked) Color(0xFFF59E0B) else Color(0xFF94A3B8)
                            )
                        }

                        FilledTonalIconButton(
                            onClick = onTogglePassthrough,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (isTouchPassthrough) Color(0xFF10B981) else Color(0x33334155),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Text(
                                text = if (isTouchPassthrough) "PASS" else "TAP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // الزر العائم الأساسي
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(56.dp)
                    .scale(buttonScale)
                    .shadow(12.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (isTranslating)
                                listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))
                            else
                                listOf(Color(0xFF4F46E5), Color(0xFF0284C7))
                        )
                    )
                    .border(2.dp, Color(0x88FFFFFF), CircleShape)
            ) {
                IconButton(
                    onClick = {
                        if (isExpanded) {
                            isExpanded = false
                        } else {
                            onTranslateClick()
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (isTranslating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "ترجمة الحوار",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // مؤشر فتح القائمة
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC0F172A))
                ) {
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = "خيارات",
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TranslationOverlayView(
    isVisible: Boolean,
    isTouchPassthrough: Boolean,
    speaker: String,
    translation: String,
    isTranslating: Boolean,
    onClose: () -> Unit,
    onRetranslate: () -> Unit,
    onTogglePassthrough: () -> Unit
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn() + scaleIn(initialScale = 0.95f),
        exit = fadeOut() + scaleOut(targetScale = 0.95f)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xEE0B1329),
                shadowElevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.5.dp,
                        if (isTouchPassthrough) Color(0xFF10B981) else Color(0x556366F1),
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1E1B4B),
                            modifier = Modifier.border(1.dp, Color(0xFF818CF8), RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = speaker,
                                color = Color(0xFFA5B4FC),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(
                                onClick = onTogglePassthrough,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isTouchPassthrough) "⚡ تمرير اللمس مفعّل" else "🖐️ لمس عادي",
                                    color = if (isTouchPassthrough) Color(0xFF34D399) else Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            IconButton(
                                onClick = onRetranslate,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "إعادة ترجمة",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            IconButton(
                                onClick = onClose,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        if (isTranslating) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF818CF8),
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "جاري استخراج النص وتوليد الصياغة الأدبية...",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 13.sp
                                )
                            }
                        } else {
                            Text(
                                text = translation,
                                color = Color(0xFFF1F5F9),
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                fontWeight = FontWeight.Normal,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}
