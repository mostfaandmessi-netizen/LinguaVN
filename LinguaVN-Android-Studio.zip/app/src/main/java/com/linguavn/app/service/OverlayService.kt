package com.linguavn.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.*
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.linguavn.app.LinguaApplication
import com.linguavn.app.MainActivity
import com.linguavn.app.R
import com.linguavn.app.domain.model.*
import com.linguavn.app.domain.ocr.MlKitOcrEngine
import com.linguavn.app.service.capture.ScreenCaptureManager
import com.linguavn.app.service.lifecycle.ServiceLifecycleOwner
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.firstOrNull
import kotlin.math.roundToInt

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val EXTRA_PROJECT_ID = "EXTRA_PROJECT_ID"
        const val NOTIFICATION_ID = 9921
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var windowManager: WindowManager
    private val lifecycleOwner = ServiceLifecycleOwner()

    private var screenCaptureManager: ScreenCaptureManager? = null
    private val ocrEngine = MlKitOcrEngine()

    private var floatingButtonView: ComposeView? = null
    private var translationOverlayView: ComposeView? = null

    private var floatingParams: WindowManager.LayoutParams? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    // Reactive State
    private var currentProjectId: Long = 1L
    private val translationState = mutableStateOf<TranslationResult?>(null)
    private val isTranslating = mutableStateOf(false)
    private val isOverlayVisible = mutableStateOf(true)
    private val isLocked = mutableStateOf(false)
    private val explainState = mutableStateOf<ExplainResult?>(null)
    private val lastExtractedText = mutableStateOf("")

    private var autoJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        lifecycleOwner.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        when (intent.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                currentProjectId = intent.getLongExtra(EXTRA_PROJECT_ID, 1L)
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData = intent.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

                startForegroundNotification()

                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    initMediaProjection(resultCode, resultData)
                    createFloatingButton()
                    createTranslationOverlay()
                    observeSettings()
                } else {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val stopIntent = Intent(this, OverlayService::class.java).apply { action = ACTION_STOP }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this, 0, mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, LinguaApplication.OVERLAY_CHANNEL_ID)
            .setContentTitle("LinguaVN - خدمة الترجمة الفورية")
            .setContentText("الزر العائم نشط فوق الألعاب")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(mainPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف الخدمة", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = mpManager.getMediaProjection(resultCode, data)

        val metrics = resources.displayMetrics
        screenCaptureManager = ScreenCaptureManager(
            mediaProjection = projection,
            screenWidth = metrics.widthPixels,
            screenHeight = metrics.heightPixels,
            screenDensity = metrics.densityDpi
        )
    }

    private fun createFloatingButton() {
        floatingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 200
        }

        floatingButtonView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                FloatingButtonComposable(
                    onTranslateClick = { triggerTranslate() },
                    onToggleOverlay = { isOverlayVisible.value = !isOverlayVisible.value },
                    onLockToggle = { isLocked.value = !isLocked.value },
                    isTranslating = isTranslating.value,
                    isLocked = isLocked.value,
                    onDrag = { dx, dy ->
                        if (!isLocked.value && floatingParams != null) {
                            floatingParams!!.x += dx.toInt()
                            floatingParams!!.y += dy.toInt()
                            windowManager.updateViewLayout(floatingButtonView, floatingParams)
                        }
                    }
                )
            }
        }

        windowManager.addView(floatingButtonView, floatingParams)
    }

    private fun createTranslationOverlay() {
        // Crucial WindowManager Touch-Passthrough implementation:
        // FLAG_NOT_FOCUSABLE passes touches outside the view through to the background game.
        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 48
        }

        translationOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                if (isOverlayVisible.value && translationState.value != null) {
                    TranslationBoxComposable(
                        result = translationState.value!!,
                        isTranslating = isTranslating.value,
                        onExplainClick = { showExplanation() },
                        onRetranslateClick = { triggerTranslate() },
                        onCloseClick = { isOverlayVisible.value = false }
                    )
                }

                explainState.value?.let { exp ->
                    ExplainDialogComposable(
                        explain = exp,
                        onDismiss = { explainState.value = null }
                    )
                }
            }
        }

        windowManager.addView(translationOverlayView, overlayParams)
    }

    private fun triggerTranslate() {
        if (isTranslating.value) return

        serviceScope.launch {
            isTranslating.value = true
            try {
                val frameBitmap = screenCaptureManager?.captureFrameBitmap()
                if (frameBitmap == null) {
                    translationState.value = TranslationResult(
                        translation = "تعذر التقاط إطار الشاشة.",
                        needsReview = true
                    )
                    return@launch
                }

                val repo = LinguaApplication.instance.repository
                val project = repo.getProject(currentProjectId)
                val region = if (project != null) {
                    DialogueRegion(project.regionX, project.regionY, project.regionWidth, project.regionHeight)
                } else null

                val lang = when (project?.originalLang) {
                    "zh" -> SupportedLanguage.CHINESE
                    "ko" -> SupportedLanguage.KOREAN
                    "en" -> SupportedLanguage.ENGLISH
                    else -> SupportedLanguage.JAPANESE
                }

                // OCR Extraction on Cropped In-RAM Image
                val extractedText = ocrEngine.extractText(frameBitmap, lang, region)
                if (extractedText.isBlank()) {
                    translationState.value = TranslationResult(
                        translation = "لم أتمكن من قراءة النص. حاول تعديل منطقة الحوار.",
                        needsReview = true
                    )
                    return@launch
                }

                lastExtractedText.value = extractedText

                // Translate via Context Engine & Gemini
                val result = repo.translateDialogue(currentProjectId, extractedText, lang)
                translationState.value = result
                isOverlayVisible.value = true

            } catch (e: Exception) {
                translationState.value = TranslationResult(
                    translation = "خطأ في المعالجة: ${e.localizedMessage}",
                    needsReview = true
                )
            } finally {
                isTranslating.value = false
            }
        }
    }

    private fun showExplanation() {
        val cur = translationState.value ?: return
        val orig = lastExtractedText.value
        serviceScope.launch {
            val repo = LinguaApplication.instance.repository
            val project = repo.getProject(currentProjectId)
            val exp = repo.explainDialogue(
                originalText = orig,
                arabicTranslation = cur.translation,
                speaker = cur.speaker,
                contextSummary = project?.contextSummary ?: ""
            )
            explainState.value = exp
        }
    }

    private fun observeSettings() {
        serviceScope.launch {
            val repo = LinguaApplication.instance.repository
            repo.overlaySettings.collect { settings ->
                if (settings.autoMode) {
                    startAutoMode(settings.autoCaptureIntervalMs)
                } else {
                    stopAutoMode()
                }
            }
        }
    }

    private fun startAutoMode(intervalMs: Long) {
        if (autoJob?.isActive == true) return
        autoJob = serviceScope.launch {
            while (isActive) {
                delay(intervalMs)
                if (!isTranslating.value && isOverlayVisible.value) {
                    // Quick check if text changed before translating
                    val frame = screenCaptureManager?.captureFrameBitmap() ?: continue
                    val repo = LinguaApplication.instance.repository
                    val project = repo.getProject(currentProjectId)
                    val region = if (project != null) {
                        DialogueRegion(project.regionX, project.regionY, project.regionWidth, project.regionHeight)
                    } else null

                    val lang = when (project?.originalLang) {
                        "zh" -> SupportedLanguage.CHINESE
                        "ko" -> SupportedLanguage.KOREAN
                        "en" -> SupportedLanguage.ENGLISH
                        else -> SupportedLanguage.JAPANESE
                    }

                    val newText = ocrEngine.extractText(frame, lang, region)
                    if (newText.isNotBlank() && newText != lastExtractedText.value) {
                        triggerTranslate()
                    }
                }
            }
        }
    }

    private fun stopAutoMode() {
        autoJob?.cancel()
        autoJob = null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAutoMode()
        serviceScope.cancel()
        screenCaptureManager?.release()
        ocrEngine.release()

        floatingButtonView?.let { windowManager.removeView(it) }
        translationOverlayView?.let { windowManager.removeView(it) }
        lifecycleOwner.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

@Composable
fun FloatingButtonComposable(
    onTranslateClick: () -> Unit,
    onToggleOverlay: () -> Unit,
    onLockToggle: () -> Unit,
    isTranslating: Boolean,
    isLocked: Boolean,
    onDrag: (Float, Float) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        FloatingActionButton(
            onClick = {
                if (expanded) expanded = false else onTranslateClick()
            },
            shape = CircleShape,
            containerColor = if (isTranslating) Color(0xFF6366F1) else Color(0xFF1E293B),
            contentColor = Color.White,
            modifier = Modifier.size(52.dp)
        ) {
            if (isTranslating) {
                CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Translate,
                    contentDescription = "ترجمة الحوار"
                )
            }
        }

        IconButton(
            onClick = { expanded = !expanded },
            modifier = Modifier
                .padding(start = 4.dp)
                .size(28.dp)
                .background(Color(0xCC0F172A), CircleShape)
        ) {
            Icon(
                imageVector = if (expanded) Icons.Default.Close else Icons.Default.MoreVert,
                contentDescription = "خيارات إضافية",
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }

        AnimatedVisibility(visible = expanded) {
            Row(
                modifier = Modifier
                    .padding(start = 4.dp)
                    .background(Color(0xEE0F172A), RoundedCornerShape(20.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onToggleOverlay() }) {
                    Icon(Icons.Default.Visibility, contentDescription = "إظهار/إخفاء", tint = Color(0xFF38BDF8))
                }
                IconButton(onClick = { onLockToggle() }) {
                    Icon(
                        if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "تثبيت الموضع",
                        tint = if (isLocked) Color(0xFFF59E0B) else Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun TranslationBoxComposable(
    result: TranslationResult,
    isTranslating: Boolean,
    onExplainClick: () -> Unit,
    onRetranslateClick: () -> Unit,
    onCloseClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xD9090D16)),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(Color(0x336366F1)))
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            // Header: Speaker + Tone Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (result.speaker != "unknown" && result.speaker.isNotBlank()) {
                        Text(
                            text = result.speaker,
                            color = Color(0xFF38BDF8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    if (result.tone.isNotBlank() && result.tone != "عادي") {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0x336366F1)
                        ) {
                            Text(
                                text = result.tone,
                                color = Color(0xFFC7D2FE),
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                // Action Buttons: [شرح] [إعادة ترجمة] [إغلاق]
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = onExplainClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("شرح", color = Color(0xFFFBBF24), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(
                        onClick = onRetranslateClick,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("إعادة ترجمة", color = Color(0xFF818CF8), fontSize = 12.sp)
                    }
                    IconButton(onClick = onCloseClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.Gray, modifier = Modifier.size(16.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Arabic Translation
            Text(
                text = result.translation,
                color = Color(0xFFF8FAFC),
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                lineHeight = 24.sp,
                textAlign = TextAlign.Start,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ExplainDialogComposable(
    explain: ExplainResult,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xF50F172A))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "تحليل وبلاغة الحوار (بدون حرق)",
                    color = Color(0xFFFBBF24),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text("• المعنى المباشر: ${explain.directMeaning}", color = Color.White, fontSize = 13.sp)
            if (explain.impliedSubtext.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text("• المعنى الضمني والمشاعر: ${explain.impliedSubtext}", color = Color(0xFFCBD5E1), fontSize = 13.sp)
            }
            if (explain.metaphorAndIdiom.isNotBlank() && explain.metaphorAndIdiom != "لا توجد استعارات خاصة") {
                Spacer(modifier = Modifier.height(6.dp))
                Text("• البلاغة والاستعارة: ${explain.metaphorAndIdiom}", color = Color(0xFF93C5FD), fontSize = 13.sp)
            }
            if (explain.culturalOrPhilosophicalRef.isNotBlank() && explain.culturalOrPhilosophicalRef != "لا توجد إشارات خارجية محددة") {
                Spacer(modifier = Modifier.height(6.dp))
                Text("• الإشارة الثقافية/الفلسفية: ${explain.culturalOrPhilosophicalRef}", color = Color(0xFFA7F3D0), fontSize = 13.sp)
            }
        }
    }
}
