package com.linguavn.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.linguavn.app.data.local.dao.LinguaDao
import com.linguavn.app.data.local.entity.*

@Database(
    entities = [
        ProjectEntity::class,
        CharacterEntity::class,
        GlossaryEntity::class,
        HistoryEntity::class,
        TranslationCacheEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class LinguaDatabase : RoomDatabase() {
    abstract fun linguaDao(): LinguaDao

    companion object {
        @Volatile
        private var INSTANCE: LinguaDatabase? = null

        fun getDatabase(context: Context): LinguaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    LinguaDatabase::class.java,
                    "linguavn_database"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
