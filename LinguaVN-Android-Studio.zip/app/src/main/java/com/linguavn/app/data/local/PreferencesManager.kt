package com.linguavn.app.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.linguavn.app.domain.model.OverlaySettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "lingua_vn_preferences")

class PreferencesManager(private val context: Context) {

    companion object {
        val KEY_FONT_SIZE = floatPreferencesKey("font_size")
        val KEY_OPACITY = floatPreferencesKey("opacity")
        val KEY_TEXT_COLOR = stringPreferencesKey("text_color")
        val KEY_BG_COLOR = stringPreferencesKey("bg_color")
        val KEY_LOCKED = booleanPreferencesKey("is_locked")
        val KEY_AUTO_MODE = booleanPreferencesKey("auto_mode")
        val KEY_ACTIVE_PROJECT_ID = longPreferencesKey("active_project_id")
        val KEY_GEMINI_KEY = stringPreferencesKey("gemini_api_key")
    }

    val overlaySettings: Flow<OverlaySettings> = context.dataStore.data.map { pref ->
        OverlaySettings(
            fontSizeSp = pref[KEY_FONT_SIZE] ?: 17f,
            backgroundOpacity = pref[KEY_OPACITY] ?: 0.82f,
            textColorHex = pref[KEY_TEXT_COLOR] ?: "#F8FAFC",
            backgroundColorHex = pref[KEY_BG_COLOR] ?: "#0F172A",
            lockPosition = pref[KEY_LOCKED] ?: false,
            autoMode = pref[KEY_AUTO_MODE] ?: false
        )
    }

    val activeProjectId: Flow<Long?> = context.dataStore.data.map { pref ->
        pref[KEY_ACTIVE_PROJECT_ID]
    }

    val geminiApiKey: Flow<String?> = context.dataStore.data.map { pref ->
        pref[KEY_GEMINI_KEY]
    }

    suspend fun updateOverlaySettings(settings: OverlaySettings) {
        context.dataStore.edit { pref ->
            pref[KEY_FONT_SIZE] = settings.fontSizeSp
            pref[KEY_OPACITY] = settings.backgroundOpacity
            pref[KEY_TEXT_COLOR] = settings.textColorHex
            pref[KEY_BG_COLOR] = settings.backgroundColorHex
            pref[KEY_LOCKED] = settings.lockPosition
            pref[KEY_AUTO_MODE] = settings.autoMode
        }
    }

    suspend fun setActiveProjectId(id: Long) {
        context.dataStore.edit { pref ->
            pref[KEY_ACTIVE_PROJECT_ID] = id
        }
    }

    suspend fun setGeminiApiKey(key: String) {
        context.dataStore.edit { pref ->
            pref[KEY_GEMINI_KEY] = key
        }
    }
}
