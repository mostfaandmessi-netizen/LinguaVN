package com.linguavn.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavn.app.LinguaApplication
import com.linguavn.app.data.local.entity.CharacterEntity
import com.linguavn.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(
    projectId: Long,
    onBack: () -> Unit
) {
    val repository = LinguaApplication.instance.repository
    val charactersFlow = remember(projectId) { repository.getCharacters(projectId) }
    val characters by charactersFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var personality by remember { mutableStateOf("") }
    var speakingStyle by remember { mutableStateOf("") }
    var formality by remember { mutableStateOf("عادي") }
    var relationship by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("قاعدة بيانات الشخصيات", color = TextPrimary, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PrimaryIndigo,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة شخصية")
            }
        },
        containerColor = BgDark
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (characters.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("لا توجد شخصيات مسجلة لهذا المشروع بعد.", color = TextSecondary, fontSize = 14.sp)
                    }
                }
            }

            items(characters, key = { it.id }) { char ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceDark
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(char.name, color = AccentCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            IconButton(
                                onClick = { scope.launch { repository.deleteCharacter(char) } },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("• الشخصية: ${char.personality}", color = TextPrimary, fontSize = 13.sp)
                        Text("• أسلوب الحديث: ${char.speakingStyle}", color = TextSecondary, fontSize = 13.sp)
                        Text("• النبرة/الرسمية: ${char.formality}", color = TextSecondary, fontSize = 12.sp)
                        if (char.notes.isNotBlank()) {
                            Text("• ملاحظات: ${char.notes}", color = AccentAmber, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("إضافة ملف شخصية", color = TextPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الشخصية") })
                        OutlinedTextField(value = personality, onValueChange = { personality = it }, label = { Text("طبيعة الشخصية") })
                        OutlinedTextField(value = speakingStyle, onValueChange = { speakingStyle = it }, label = { Text("أسلوب الحديث (هادئ، ساخر، رسمي...)") })
                        OutlinedTextField(value = formality, onValueChange = { formality = it }, label = { Text("درجة الرسمية والنبرة") })
                        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات خاصة للترجمة") })
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                scope.launch {
                                    repository.insertCharacter(
                                        CharacterEntity(
                                            projectId = projectId,
                                            name = name,
                                            personality = personality,
                                            speakingStyle = speakingStyle,
                                            formality = formality,
                                            relationship = relationship,
                                            notes = notes
                                        )
                                    )
                                    name = ""
                                    personality = ""
                                    speakingStyle = ""
                                    notes = ""
                                    showAddDialog = false
                                }
                            }
                        }
                    ) { Text("حفظ") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) { Text("إلغاء") }
                },
                containerColor = SurfaceDark
            )
        }
    }
}
