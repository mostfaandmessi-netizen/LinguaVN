package com.linguavn.app.data.local.dao

import androidx.room.*
import com.linguavn.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface LinguaDao {

    // Projects
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun getAllProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: ProjectEntity): Long

    @Update
    suspend fun updateProject(project: ProjectEntity)

    @Delete
    suspend fun deleteProject(project: ProjectEntity)

    // Characters
    @Query("SELECT * FROM characters WHERE projectId = :projectId ORDER BY name ASC")
    fun getCharactersByProject(projectId: Long): Flow<List<CharacterEntity>>

    @Query("SELECT * FROM characters WHERE projectId = :projectId")
    suspend fun getCharactersList(projectId: Long): List<CharacterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCharacter(character: CharacterEntity): Long

    @Delete
    suspend fun deleteCharacter(character: CharacterEntity)

    // Glossary
    @Query("SELECT * FROM glossary WHERE projectId = :projectId ORDER BY original ASC")
    fun getGlossaryByProject(projectId: Long): Flow<List<GlossaryEntity>>

    @Query("SELECT * FROM glossary WHERE projectId = :projectId")
    suspend fun getGlossaryList(projectId: Long): List<GlossaryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGlossary(term: GlossaryEntity): Long

    @Delete
    suspend fun deleteGlossary(term: GlossaryEntity)

    // History
    @Query("SELECT * FROM translation_history WHERE projectId = :projectId ORDER BY timestamp DESC")
    fun getHistoryByProject(projectId: Long): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM translation_history WHERE projectId = :projectId ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentHistory(projectId: Long, limit: Int = 10): List<HistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity): Long

    @Query("UPDATE translation_history SET userCorrection = :correction WHERE id = :id")
    suspend fun updateHistoryCorrection(id: Long, correction: String)

    // Cache
    @Query("SELECT * FROM translation_cache WHERE textHash = :hash LIMIT 1")
    suspend fun getCachedTranslation(hash: String): TranslationCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCache(cache: TranslationCacheEntity)
}
