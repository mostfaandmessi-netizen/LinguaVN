package com.linguavn.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavn.app.LinguaApplication
import com.linguavn.app.data.local.entity.GlossaryEntity
import com.linguavn.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlossaryScreen(
    projectId: Long,
    onBack: () -> Unit
) {
    val repository = LinguaApplication.instance.repository
    val glossaryFlow = remember(projectId) { repository.getGlossary(projectId) }
    val glossaryList by glossaryFlow.collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var original by remember { mutableStateOf("") }
    var translation by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المسرد والمصطلحات (Glossary)", color = TextPrimary, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PrimaryIndigo,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "إضافة مصطلح")
            }
        },
        containerColor = BgDark
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (glossaryList.isEmpty()) {
                item {
                    Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                        Text("لا توجد مصطلحات في المسرد بعد.", color = TextSecondary, fontSize = 14.sp)
                    }
                }
            }

            items(glossaryList, key = { it.id }) { term ->
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    color = SurfaceDark
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(term.original, color = AccentCyan, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("←", color = TextSecondary)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(term.translation, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (term.notes.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("ملاحظة: ${term.notes}", color = TextSecondary, fontSize = 12.sp)
                            }
                        }

                        IconButton(
                            onClick = { scope.launch { repository.deleteGlossary(term) } }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        if (showAddDialog) {
            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                title = { Text("إضافة مصطلح جديد", color = TextPrimary) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = original, onValueChange = { original = it }, label = { Text("الكلمة الأصلية (مثال: サクラノ詩)") })
                        OutlinedTextField(value = translation, onValueChange = { translation = it }, label = { Text("الترجمة العربية الإلزامية") })
                        OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات سياقية إضافية") })
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (original.isNotBlank() && translation.isNotBlank()) {
                                scope.launch {
                                    repository.insertGlossary(
                                        GlossaryEntity(
                                            projectId = projectId,
                                            original = original,
                                            translation = translation,
                                            notes = notes,
                                            isPreferred = true
                                        )
                                    )
                                    original = ""
                                    translation = ""
                                    notes = ""
                                    showAddDialog = false
                                }
                            }
                        }
                    ) { Text("حفظ") }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) { Text("إلغاء") }
                },
                containerColor = SurfaceDark
            )
        }
    }
}
