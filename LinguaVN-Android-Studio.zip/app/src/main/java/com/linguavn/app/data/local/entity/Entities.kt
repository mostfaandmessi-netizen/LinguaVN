package com.linguavn.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val originalLang: String = "ja",
    val targetLang: String = "ar",
    val translationMode: String = "LITERARY_NATURAL",
    val contextSummary: String = "",
    val regionX: Float = 0.05f,
    val regionY: Float = 0.65f,
    val regionWidth: Float = 0.90f,
    val regionHeight: Float = 0.30f,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

@Entity(tableName = "characters")
data class CharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val name: String,
    val personality: String,
    val speakingStyle: String,
    val formality: String = "رسمي / مؤدب",
    val relationship: String = "",
    val commonExpressions: String = "",
    val notes: String = ""
) : Serializable

@Entity(tableName = "glossary")
data class GlossaryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val original: String,
    val translation: String,
    val notes: String = "",
    val isPreferred: Boolean = true
) : Serializable

@Entity(tableName = "translation_history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val originalText: String,
    val arabicTranslation: String,
    val speaker: String = "unknown",
    val tone: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val context: String = "",
    val userCorrection: String? = null
) : Serializable

@Entity(tableName = "translation_cache")
data class TranslationCacheEntity(
    @PrimaryKey val textHash: String,
    val originalText: String,
    val jsonResult: String,
    val timestamp: Long = System.currentTimeMillis()
)
