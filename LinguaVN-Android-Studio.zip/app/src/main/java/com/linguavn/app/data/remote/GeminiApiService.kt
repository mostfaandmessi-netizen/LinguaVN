package com.linguavn.app.data.remote

import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.generationConfig
import com.linguavn.app.domain.model.ExplainResult
import com.linguavn.app.domain.model.TranslationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

class GeminiApiService(private val apiKeyProvider: suspend () -> String) {

    private fun hashText(text: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        val bytes = md.digest(text.trim().toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun computeHash(text: String, mode: String, projectId: Long): String {
        return hashText("$projectId:$mode:$text")
    }

    suspend fun translateWithGemini(prompt: String): TranslationResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider()
        if (apiKey.isBlank()) {
            return@withContext TranslationResult(
                speaker = "unknown",
                tone = "تنبيه",
                translation = "يرجى ضبط مفتاح Gemini API Key في الإعدادات للبدء.",
                confidence = 0.0,
                needsReview = true
            )
        }

        try {
            val generativeModel = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = apiKey,
                generationConfig = generationConfig {
                    temperature = 0.3f
                    responseMimeType = "application/json"
                }
            )

            val response = generativeModel.generateContent(prompt)
            val jsonText = response.text?.trim() ?: "{}"
            parseTranslationJson(jsonText)
        } catch (e: Exception) {
            e.printStackTrace()
            TranslationResult(
                speaker = "unknown",
                tone = "خطأ",
                translation = "تعذر الاتصال بـ Gemini API: ${e.localizedMessage ?: "خطأ غير معروف"}",
                confidence = 0.0,
                needsReview = true
            )
        }
    }

    suspend fun explainDialogue(
        originalText: String,
        arabicTranslation: String,
        speaker: String,
        contextSummary: String
    ): ExplainResult = withContext(Dispatchers.IO) {
        val apiKey = apiKeyProvider()
        if (apiKey.isBlank()) {
            return@withContext ExplainResult(
                directMeaning = "مفتاح API غير متوفر",
                impliedSubtext = "",
                tone = "",
                metaphorAndIdiom = "",
                culturalOrPhilosophicalRef = ""
            )
        }

        val prompt = """
أنت خبير أدبي في ثقافة الروايات المرئية (Visual Novels) والألعاب.
قدم شرحاً عميقاً بدون أي حرق للأحداث (Spoiler-Free) لهذا الحوار:
- النص الأصلي: "$originalText"
- المتحدث: "$speaker"
- الترجمة العربية: "$arabicTranslation"
- السياق: "$contextSummary"

أعد الإجابة بـ JSON:
{
  "direct_meaning": "المعنى الصريح المباشر للكلمات",
  "implied_subtext": "المعنى الخفي والمشاعر الباطنة غير المنطوقة",
  "tone": "نبرة الحديث ودلالتها النفسية",
  "metaphor_and_idiom": "الاستعارة أو الكناية أو التعبير الاصطلاحي",
  "cultural_or_philosophical_ref": "المرجع الثقافي أو الأدبي أو الفلسفي (مع التنبيه إن كان احتمالاً فقط)"
}
""".trimIndent()

        try {
            val generativeModel = GenerativeModel(
                modelName = "gemini-1.5-flash",
                apiKey = apiKey,
                generationConfig = generationConfig {
                    temperature = 0.4f
                    responseMimeType = "application/json"
                }
            )

            val response = generativeModel.generateContent(prompt)
            val json = JSONObject(response.text?.trim() ?: "{}")

            ExplainResult(
                directMeaning = json.optString("direct_meaning", "غير متوفر"),
                impliedSubtext = json.optString("implied_subtext", "غير متوفر"),
                tone = json.optString("tone", "عادي"),
                metaphorAndIdiom = json.optString("metaphor_and_idiom", "لا توجد استعارات خاصة"),
                culturalOrPhilosophicalRef = json.optString("cultural_or_philosophical_ref", "لا توجد إشارات خارجية محددة")
            )
        } catch (e: Exception) {
            ExplainResult(
                directMeaning = "تعذر جلب الشرح المفصل: ${e.localizedMessage}",
                impliedSubtext = "",
                tone = "",
                metaphorAndIdiom = "",
                culturalOrPhilosophicalRef = ""
            )
        }
    }

    private fun parseTranslationJson(jsonStr: String): TranslationResult {
        return try {
            val json = JSONObject(jsonStr)
            val literaryElements = mutableListOf<String>()
            val references = mutableListOf<String>()

            val litArray = json.optJSONArray("literary_elements") ?: JSONArray()
            for (i in 0 until litArray.length()) {
                literaryElements.add(litArray.optString(i))
            }

            val refArray = json.optJSONArray("references") ?: JSONArray()
            for (i in 0 until refArray.length()) {
                references.add(refArray.optString(i))
            }

            TranslationResult(
                speaker = json.optString("speaker", "unknown"),
                tone = json.optString("tone", "عادي"),
                translation = json.optString("translation", ""),
                confidence = json.optDouble("confidence", 0.95),
                literalMeaning = json.optString("literal_meaning", ""),
                literaryElements = literaryElements,
                references = references,
                needsReview = json.optBoolean("needs_review", false)
            )
        } catch (e: Exception) {
            TranslationResult(
                speaker = "unknown",
                tone = "عادي",
                translation = jsonStr,
                confidence = 0.8
            )
        }
    }
}
