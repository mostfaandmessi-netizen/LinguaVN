package com.linguavn.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.linguavn.app.MainActivity
import com.linguavn.app.service.lifecycle.ServiceLifecycleOwner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlin.math.max
import kotlin.math.min

/**
 * TranslationOverlayService
 * -------------------------------------------------------------
 * Foreground Service مخصص لإدارة وتثبيت الزر العائم (Floating Button)
 * ولوحة الترجمة الفوقية (Overlay) المخصصة للروايات المرئية (Visual Novels) والألعاب.
 *
 * الخصائص الأساسية:
 * 1. Foreground Service مع دعم كامل لـ Android 14+ (foregroundServiceType="mediaProjection").
 * 2. ربط دورة حياة Jetpack Compose عبر ComposeView و ServiceLifecycleOwner.
 * 3. تمرير اللمسات (Touch Passthrough) باستخدام WindowManager:
 *    - FLAG_NOT_FOCUSABLE: يمنع حجب زر الرجوع أو لوحة المفاتيح في اللعبة الأصلية.
 *    - FLAG_NOT_TOUCH_MODAL: يسمح بمرور اللمسات الواقعة خارج الزر العائم إلى اللعبة.
 *    - وضع النقر التمريري (Click-Through Passthrough): تفعيل FLAG_NOT_TOUCHABLE لجعل
 *      صندوق الترجمة شفافاً تماماً للمس حتى يتمكن اللاعب من النقر لتقديم الحوار (Advance Dialogue).
 */
class TranslationOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.linguavn.app.service.ACTION_START"
        const val ACTION_STOP = "com.linguavn.app.service.ACTION_STOP"
        const val ACTION_TOGGLE_PASSTHROUGH = "com.linguavn.app.service.ACTION_TOGGLE_PASSTHROUGH"
        
        const val NOTIFICATION_CHANNEL_ID = "lingua_overlay_channel"
        const val NOTIFICATION_ID = 9021
    }

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private lateinit var windowManager: WindowManager
    private val lifecycleOwner = ServiceLifecycleOwner()

    // Compose Views المدارة داخل الـ WindowManager
    private var floatingButtonView: ComposeView? = null
    private var translationOverlayView: ComposeView? = null

    // WindowManager Layout Parameters
    private var floatingParams: WindowManager.LayoutParams? = null
    private var overlayParams: WindowManager.LayoutParams? = null

    // أبعاد الشاشة لحساب حدود السحب (Drag Boundaries)
    private var screenWidth = 1080
    private var screenHeight = 2400

    // الحالات التفاعلية (Reactive Compose States)
    private val isTranslatingState = mutableStateOf(false)
    private val isOverlayVisibleState = mutableStateOf(true)
    private val isLockedState = mutableStateOf(false)
    private val isTouchPassthroughState = mutableStateOf(false)
    private val translationTextState = mutableStateOf("اضغط على الزر العائم لالتقاط وترجمة حوار الرواية...")
    private val speakerNameState = mutableStateOf("LinguaVN")

    override fun onCreate() {
        super.onCreate()
        lifecycleOwner.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        updateScreenDimensions()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) return START_NOT_STICKY

        when (intent.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PASSTHROUGH -> {
                toggleTouchPassthrough()
            }
            ACTION_START, null -> {
                startForegroundServiceNotification()
                if (floatingButtonView == null) {
                    setupFloatingButton()
                    setupTranslationOverlay()
                }
            }
        }

        return START_STICKY
    }

    /**
     * تحديث أبعاد الشاشة الحالية لدعم التدوير وحساب حدود السحب
     */
    private fun updateScreenDimensions() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
    }

    /**
     * تهيئة إشعار الـ Foreground Service لضمان استقرار الخدمة في الخلفية (Android 14+)
     */
    private fun startForegroundServiceNotification() {
        val stopIntent = Intent(this, TranslationOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainActivityIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("LinguaVN - خدمة الترجمة العائمة")
            .setContentText("الزر العائم وتمرير اللمسات نشط فوق شاشة اللعبة")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(mainPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف الخدمة", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "خدمة الزر العائم والترجمة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "قناة إشعار Foreground Service لخدمة ترجمة الروايات المرئية"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * 1. إنشاء وربط الـ ComposeView للزر العائم مع WindowManager
     * -----------------------------------------------------------
     * مع إعدادات Touch Passthrough الصارمة:
     * - FLAG_NOT_FOCUSABLE: يضمن عدم اعتراض مفاتيح النظام مثل الرجوع.
     * - FLAG_NOT_TOUCH_MODAL: يمرر اللمسات الواقعة خارج مساحة الزر العائم مباشرة للعبة.
     */
    private fun setupFloatingButton() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        floatingParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 32
            y = 320
        }

        floatingButtonView = ComposeView(this).apply {
            // ربط دورة الحياة الضرورية لـ Jetpack Compose داخل الـ Service
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            // الاستماع لأحداث اللمس الخارجية لتأكيد تمرير اللمسات بنجاح إلى اللعبة
            setOnTouchListener { _, event ->
                if (event.action == MotionEvent.ACTION_OUTSIDE) {
                    true
                } else {
                    false
                }
            }

            setContent {
                FloatingButtonComponent(
                    isTranslating = isTranslatingState.value,
                    isOverlayVisible = isOverlayVisibleState.value,
                    isLocked = isLockedState.value,
                    isTouchPassthrough = isTouchPassthroughState.value,
                    onTranslateClick = { onTriggerTranslation() },
                    onToggleOverlayVisibility = { isOverlayVisibleState.value = !isOverlayVisibleState.value },
                    onToggleLock = { isLockedState.value = !isLockedState.value },
                    onTogglePassthrough = { toggleTouchPassthrough() },
                    onDragDelta = { deltaX, deltaY ->
                        handleButtonDrag(deltaX, deltaY)
                    }
                )
            }
        }

        windowManager.addView(floatingButtonView, floatingParams)
    }

    /**
     * 2. إنشاء وربط ComposeView للوحة الترجمة (Overlay Subtitle Box)
     * -------------------------------------------------------------
     * يدعم تقنية Touch Passthrough:
     * - عند تفعيل isTouchPassthrough = true:
     *   يُضاف FLAG_NOT_TOUCHABLE بحيث تمر أي لمسة فوق صندوق الترجمة مباشرة إلى اللعبة لتقديم الحوار!
     */
    private fun setupTranslationOverlay() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        overlayParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            getOverlayWindowFlags(isTouchPassthroughState.value),
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 64
        }

        translationOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(lifecycleOwner)
            setViewTreeViewModelStoreOwner(lifecycleOwner)
            setViewTreeSavedStateRegistryOwner(lifecycleOwner)

            setContent {
                TranslationOverlayComponent(
                    isVisible = isOverlayVisibleState.value,
                    isTouchPassthrough = isTouchPassthroughState.value,
                    speaker = speakerNameState.value,
                    translation = translationTextState.value,
                    isTranslating = isTranslatingState.value,
                    onCloseClick = { isOverlayVisibleState.value = false },
                    onRetranslateClick = { onTriggerTranslation() },
                    onTogglePassthroughClick = { toggleTouchPassthrough() }
                )
            }
        }

        windowManager.addView(translationOverlayView, overlayParams)
    }

    /**
     * حساب أعلام WindowManager حسب وضع تمرير اللمس (Touch Passthrough)
     */
    private fun getOverlayWindowFlags(isPassthrough: Boolean): Int {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        if (isPassthrough) {
            // تفعيل التمرير الكامل للمسات: اللمسات تمر مباشرة لطبقة اللعبة الموجودة بالخلف
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        return flags
    }

    /**
     * التبديل بين وضع التفاعل العادي ووضع تمرير اللمسات (Touch Passthrough)
     */
    private fun toggleTouchPassthrough() {
        val newPassthrough = !isTouchPassthroughState.value
        isTouchPassthroughState.value = newPassthrough

        overlayParams?.let { params ->
            params.flags = getOverlayWindowFlags(newPassthrough)
            translationOverlayView?.let { view ->
                windowManager.updateViewLayout(view, params)
            }
        }
    }

    /**
     * معالجة سحب الزر العائم وتحديث إحداثياته بسلاسة مع تقييده بحدود الشاشة
     */
    private fun handleButtonDrag(deltaX: Float, deltaY: Float) {
        if (isLockedState.value || floatingParams == null || floatingButtonView == null) return

        floatingParams?.let { params ->
            val newX = params.x + deltaX.toInt()
            val newY = params.y + deltaY.toInt()

            // تقييد الإحداثيات داخل أبعاد الشاشة
            params.x = max(0, min(newX, screenWidth - 160))
            params.y = max(40, min(newY, screenHeight - 200))

            windowManager.updateViewLayout(floatingButtonView, params)
        }
    }

    /**
     * محاكاة طلب الترجمة
     */
    private fun onTriggerTranslation() {
        isTranslatingState.value = true
        isOverlayVisibleState.value = true

        // محاكاة استجابة نموذج الذكاء الاصطناعي الأدبية
        floatingButtonView?.postDelayed({
            isTranslatingState.value = false
            speakerNameState.value = "الراوي"
            translationTextState.value = "تحت شجرة الكرز، تهمس الرياح بأسرار الماضي التي لا تموت."
        }, 1200)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleOwner.onDestroy()
        serviceScope.cancel()

        // إزالة المشاهد المعلقة بأمان من WindowManager
        try {
            floatingButtonView?.let { windowManager.removeView(it) }
            translationOverlayView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        floatingButtonView = null
        translationOverlayView = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

/* =============================================================================
 * Jetpack Compose Components للزر العائم وشريط الترجمة
 * ============================================================================= */

/**
 * مكون الزر العائم (Floating Action Button) بنمط بصري مريح للاعبين
 */
@Composable
fun FloatingButtonComponent(
    isTranslating: Boolean,
    isOverlayVisible: Boolean,
    isLocked: Boolean,
    isTouchPassthrough: Boolean,
    onTranslateClick: () -> Unit,
    onToggleOverlayVisibility: () -> Unit,
    onToggleLock: () -> Unit,
    onTogglePassthrough: () -> Unit,
    onDragDelta: (Float, Float) -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    val scale by animateFloatAsState(
        targetValue = if (isTranslating) 1.12f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "fabScale"
    )

    Box(
        modifier = Modifier
            .wrapContentSize()
            .pointerInput(isLocked) {
                if (!isLocked) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragDelta(dragAmount.x, dragAmount.y)
                    }
                }
            }
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // القائمة السريعة عند التوسيع
            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xEE1E293B),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .border(1.dp, Color(0x446366F1), RoundedCornerShape(16.dp))
                        .padding(4.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(4.dp)
                    ) {
                        // زر إخفاء / إظهار اللوحة
                        IconButton(
                            onClick = onToggleOverlayVisibility,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isOverlayVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = "إظهار/إخفاء اللوحة",
                                tint = if (isOverlayVisible) Color(0xFF38BDF8) else Color(0xFF94A3B8)
                            )
                        }

                        // زر قفل موضع الزر لمنع السحب العرضي
                        IconButton(
                            onClick = onToggleLock,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = "قفل الموضع",
                                tint = if (isLocked) Color(0xFFF59E0B) else Color(0xFF94A3B8)
                            )
                        }

                        // زر تفعيل / تعطيل تمرير اللمس (Touch Passthrough)
                        FilledTonalIconButton(
                            onClick = onTogglePassthrough,
                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                containerColor = if (isTouchPassthrough) Color(0xFF10B981) else Color(0x33334155),
                                contentColor = Color.White
                            ),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Text(
                                text = if (isTouchPassthrough) "PASS" else "TAP",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // الزر العائم الأساسي (Main Floating Button)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(56.dp)
                    .scale(scale)
                    .shadow(12.dp, CircleShape)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = if (isTranslating)
                                listOf(Color(0xFF8B5CF6), Color(0xFFEC4899))
                            else
                                listOf(Color(0xFF4F46E5), Color(0xFF0284C7))
                        )
                    )
                    .border(2.dp, Color(0x88FFFFFF), CircleShape)
            ) {
                IconButton(
                    onClick = {
                        if (isExpanded) {
                            isExpanded = false
                        } else {
                            onTranslateClick()
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) {
                    if (isTranslating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(24.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Translate,
                            contentDescription = "ترجمة الحوار",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // مؤشر صغير لفتح القائمة المساعدة
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(2.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xCC0F172A))
                        .pointerInput(Unit) {
                            detectDragGestures { _, _ -> }
                        }
                ) {
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.Close else Icons.Default.Refresh,
                            contentDescription = "خيارات سريعة",
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                }
            }
        }
    }
}

/**
 * مكون لوحة الترجمة الفوقية (Translation Overlay Subtitle Box)
 * صُمم خصيصاً ليناسب الخطوط والروايات المرئية مع دعم الشفافية وتمرير اللمس.
 */
@Composable
fun TranslationOverlayComponent(
    isVisible: Boolean,
    isTouchPassthrough: Boolean,
    speaker: String,
    translation: String,
    isTranslating: Boolean,
    onCloseClick: () -> Unit,
    onRetranslateClick: () -> Unit,
    onTogglePassthroughClick: () -> Unit
) {
    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn() + scaleIn(initialScale = 0.95f),
        exit = fadeOut() + scaleOut(targetScale = 0.95f)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xEE0B1329),
                shadowElevation = 16.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.5.dp,
                        if (isTouchPassthrough) Color(0xFF10B981) else Color(0x556366F1),
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // شريط العنوان والشخصية
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // اسم المتحدث
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1E1B4B),
                            modifier = Modifier.border(1.dp, Color(0xFF818CF8), RoundedCornerShape(8.dp))
                        ) {
                            Text(
                                text = speaker,
                                color = Color(0xFFA5B4FC),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }

                        // أزرار التحكم
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // مؤشر Touch Passthrough
                            TextButton(
                                onClick = onTogglePassthroughClick,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (isTouchPassthrough) "⚡ تمرير اللمس مفعّل" else "🖐️ لمس عادي",
                                    color = if (isTouchPassthrough) Color(0xFF34D399) else Color(0xFF94A3B8),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            // إعادة الترجمة
                            IconButton(
                                onClick = onRetranslateClick,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "إعادة ترجمة",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // إغلاق اللوحة
                            IconButton(
                                onClick = onCloseClick,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "إغلاق",
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    // نص الترجمة الأدبية الفصيحة
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        if (isTranslating) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color(0xFF818CF8),
                                    strokeWidth = 2.dp
                                )
                                Text(
                                    text = "جاري استخراج النص وتوليد الصياغة الأدبية بالذكاء الاصطناعي...",
                                    color = Color(0xFF94A3B8),
                                    fontSize = 13.sp
                                )
                            }
                        } else {
                            Text(
                                text = translation,
                                color = Color(0xFFF1F5F9),
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                fontWeight = FontWeight.Normal,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}
