package com.linguavn.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.linguavn.app.LinguaApplication
import com.linguavn.app.domain.model.OverlaySettings
import com.linguavn.app.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    val repository = LinguaApplication.instance.repository
    val settings by repository.overlaySettings.collectAsState(initial = OverlaySettings())
    val geminiKey by repository.geminiApiKey.collectAsState(initial = "")
    val scope = rememberCoroutineScope()

    var apiKeyInput by remember(geminiKey) { mutableStateOf(geminiKey ?: "") }
    var showKeySavedToast by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("إعدادات التطبيق و الـ Overlay", color = TextPrimary, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "رجوع", tint = TextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = BgDark)
            )
        },
        containerColor = BgDark
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Overlay Visual Customization Section
            Text("مظهر صندوق الترجمة (Overlay Box)", color = AccentCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)

            Surface(shape = RoundedCornerShape(12.dp), color = SurfaceDark) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Font Size Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("حجم خط الترجمة:", color = TextPrimary, fontSize = 14.sp)
                        Text("${settings.fontSizeSp.toInt()} sp", color = AccentAmber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.fontSizeSp,
                        onValueChange = { scope.launch { repository.saveOverlaySettings(settings.copy(fontSizeSp = it)) } },
                        valueRange = 13f..26f,
                        steps = 13
                    )

                    // Opacity Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("شفافية الصندوق الخلفي:", color = TextPrimary, fontSize = 14.sp)
                        Text("${(settings.backgroundOpacity * 100).toInt()}%", color = AccentAmber, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = settings.backgroundOpacity,
                        onValueChange = { scope.launch { repository.saveOverlaySettings(settings.copy(backgroundOpacity = it)) } },
                        valueRange = 0.20f..1.0f
                    )

                    // Auto Mode Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("الوضع التلقائي (Auto Mode)", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("التقاط الحوار دورياً فقط عند تغير النص (Cache مدعوم)", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = settings.autoMode,
                            onCheckedChange = { scope.launch { repository.saveOverlaySettings(settings.copy(autoMode = it)) } }
                        )
                    }
                }
            }

            // Gemini API Key Section
            Text("إعداد مفتاح Gemini API", color = AccentCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Surface(shape = RoundedCornerShape(12.dp), color = SurfaceDark) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "يستخدم LinguaVN نموذج Gemini لتقديم ترجمة عربية أدبية وسياقية دون حرق.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = { apiKeyInput = it },
                        label = { Text("Gemini API Key") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            scope.launch {
                                repository.setGeminiApiKey(apiKeyInput.trim())
                                showKeySavedToast = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryIndigo),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("حفظ المفتاح")
                    }
                    if (showKeySavedToast) {
                        Text("✓ تم حفظ المفتاح بنجاح محلياً في DataStore المشفر.", color = Color(0xFF34D399), fontSize = 12.sp)
                    }
                }
            }

            // Android Permissions Explanations (Required by User Prompt)
            Text("شرح الصلاحيات المطلوبة (Permissions)", color = AccentCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Surface(shape = RoundedCornerShape(12.dp), color = SurfaceDark) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("1. الظهور فوق التطبيقات (Display Over Other Apps):", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("لعرض الزر العائم وصندوق الترجمة الشفاف فوق شاشة اللعبة أثناء تشغيلها.", color = TextSecondary, fontSize = 12.sp)

                    Divider(color = BorderSubtle)

                    Text("2. التقاط الشاشة (MediaProjection / Screen Capture):", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("لالتقاط منطقة الحوار في الذاكرة RAM فقط دون حفظها في التخزين، واستخراج النص عبر ML Kit OCR المحلي.", color = TextSecondary, fontSize = 12.sp)
                }
            }
        }
    }
}
