# LinguaVN ProGuard Rules
-keep class com.google.mlkit.** { *; }
-keep class com.google.ai.client.generativeai.** { *; }
-keepclassmembers class * {
    @androidx.room.* *;
}
